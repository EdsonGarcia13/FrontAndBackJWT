import axios from "axios";
import authHeader from "./auth-header";
const API_URL = "/posts";
const getAllPedidos = () => {
  return axios.get(API_URL + "/pedido", { headers: authHeader() });
};

const updatePedidoEstatus = (id, pedido) => {
  return axios.put(API_URL + `/pedido/${id}`, pedido, { headers: authHeader() });
};

const getProductoByHawa = (hawa) => {
  return axios.get(API_URL + `/producto/${hawa}`);
};

const getAllproducts = () => {
  return axios.get(API_URL + "/producto", { headers: authHeader() });
};
const createPedido = (pedido) => {
  return axios.post(API_URL + "/pedido", pedido, { headers: authHeader() });
};

const postService = {
  getAllProducts,
  updatePedidoEstatus,
  getProductoByHawa,
  createPedido,
  getAllproducts,
  getAllPedidos
};

export default postService;
