import React, { useState, useEffect } from "react";

import { useState, useEffect } from "react";
import postService from "./post.service";
import Producto from "./clases/Producto";
import Pedido from "./clases/Pedido";

const Home = () => {
  const [productos, setProductos] = useState([]);
  const [productoSeleccionado, setProductoSeleccionado] = useState(new Producto(null, null, null, null));
  const [cantidad, setCantidad] = useState(1);
  const [pedido, setPedido] = useState(new Pedido(null, new Date(), "192.168.1.1", "tienda1", "cliente1", "vendedor1", 0.1, "pendiente", []));

  useEffect(() => {
    postService.getAllPedidos().then((response) => {
      setProductos(response.data);
    });
  }, []);

  const handleProductoSeleccionado = (producto) => {
    setProductoSeleccionado(producto);
  };

  const handleCantidadChange = (event) => {
    setCantidad(event.target.value);
  };

  const handleAgregarProducto = () => {
    const productoExistente = pedido.productos.find((p) => p.hawa === productoSeleccionado.hawa);
    if (productoExistente) {
      productoExistente.existencias += cantidad;
    } else {
      const productoNuevo = new Producto(productoSeleccionado.hawa, productoSeleccionado.precioLista, productoSeleccionado.descuento, cantidad);
      pedido.productos.push(productoNuevo);
    }
    setPedido(pedido);
    setProductoSeleccionado(new Producto(null, null, null, null));
    setCantidad(1);
  };

  const handleEstatusChange = (event) => {
    const estatus = event.target.value;
    setPedido({ ...pedido, estatus });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    postService.createPedido(pedido).then((response) => {
      console.log(response.data);
    });
  };
  const [hawa, setHawa] = useState("");
  const [producto, setProducto] = useState(null);

  const handleHawaChange = (event) => {
    setHawa(event.target.value);
  };

  const handleBuscarClick = () => {
    postService.getProductoByHawa(hawa).then((response) => {
      setProducto(response.data);
    });
  };
  return (
    <div>
       <h2>Home</h2>
      <div>
        <label htmlFor="hawa">Hawa:</label>
        <input id="hawa" name="hawa" type="text" value={hawa} onChange={handleHawaChange} />
        <button type="button" onClick={handleBuscarClick}>
          Buscar
        </button>
      </div>
      {producto && (
        <div>
          <h3>{producto.hawa}</h3>
          <p>Precio Lista: {producto.precioLista}</p>
          <p>Descuento: {producto.descuento}</p>
          <p>Existencias: {producto.existencias}</p>
        </div>
      )}
      <h2>Crear Pedido</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="estatus">Estatus:</label>
          <select id="estatus" name="estatus" value={pedido.estatus} onChange={handleEstatusChange}>
            <option value="pendiente">Pendiente</option>
            <option value="enviado">Enviado</option>
            <option value="entregado">Entregado</option>
          </select>
        </div>
        <div>
          <label htmlFor="producto">Producto:</label>
          <select id="producto" name="producto" value={productoSeleccionado.hawa} onChange={(event) => handleProductoSeleccionado(productos.find((p) => p.hawa === parseInt(event.target.value)))}>
            <option value="">Selecciona un producto</option>
            {productos.map((producto) => (
              <option key={producto.hawa} value={producto.hawa}>
                {producto.hawa} - {producto.precioLista}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="cantidad">Cantidad:</label>
          <input id="cantidad" name="cantidad" type="number" min="1" value={cantidad} onChange={handleCantidadChange} />
        </div>
        <button type="button" onClick={handleAgregarProducto}>
          Agregar Producto
        </button>
        <ul>
          {pedido.productos.map((producto) => (
            <li key={producto.hawa}>
              {producto.hawa} - {producto.precioLista} - {producto.existencias}
            </li>
          ))}
        </ul>
        <button type="submit">Crear Pedido</button>
      </form>
    </div>
  );
};

export default Home;
