import { useState, useEffect } from "react";
import postService from "./post.service";

const Private = () => {
  const [pedidos, setPedidos] = useState([]);
  const [pedidoSeleccionado, setPedidoSeleccionado] = useState(null);
  const [nuevoEstatus, setNuevoEstatus] = useState("");

  useEffect(() => {
    postService.getAllPedidos().then((response) => {
      setPedidos(response.data);
    });
  }, []);

  const handlePedidoClick = (pedido) => {
    setPedidoSeleccionado(pedido);
  };

  const handleEstatusChange = (event) => {
    setNuevoEstatus(event.target.value);
  };

  const handleActualizarEstatus = () => {
    postService.updatePedidoEstatus(pedidoSeleccionado.id, { ...pedidoSeleccionado, estatus: nuevoEstatus }).then((response) => {
      setPedidos(pedidos.map((p) => (p.id === pedidoSeleccionado.id ? response.data : p)));
      setPedidoSeleccionado(null);
      setNuevoEstatus("");
    });
  };

  return (
    <div>
      <h2>Lista de Pedidos</h2>
      <ul>
        {pedidos.map((pedido) => (
          <li key={pedido.id} onClick={() => handlePedidoClick(pedido)}>
            {pedido.id} - {pedido.fecha} - {pedido.tienda} - {pedido.cliente} - {pedido.vendedor} - {pedido.estatus}
          </li>
        ))}
      </ul>
      {pedidoSeleccionado && (
        <div>
          <h3>Pedido {pedidoSeleccionado.id}</h3>
          <p>Fecha: {pedidoSeleccionado.fecha}</p>
          <p>Tienda: {pedidoSeleccionado.tienda}</p>
          <p>Cliente: {pedidoSeleccionado.cliente}</p>
          <p>Vendedor: {pedidoSeleccionado.vendedor}</p>
          <div>
            <label htmlFor="estatus">Estatus:</label>
            <select id="estatus" name="estatus" value={nuevoEstatus} onChange={handleEstatusChange}>
              <option value="pendiente">Pendiente</option>
              <option value="enviado">Enviado</option>
              <option value="entregado">Entregado</option>
            </select>
            <button type="button" onClick={handleActualizarEstatus}>
              Actualizar Estatus
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Private;