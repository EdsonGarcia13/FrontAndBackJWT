

class Pedido {
  constructor(
    public id: number,
    public fecha: Date,
    public ipUsuario: string,
    public tienda: string,
    public cliente: string,
    public vendedor: string,
    public descuento: number,
    public estatus: string,
    public productos: Producto[]
  ) {}
}