
class Products {
  constructor(
    public hawa: number,
    public precioLista: number,
    public descuento: number,
    public existencias: number
  ) {}
  

}