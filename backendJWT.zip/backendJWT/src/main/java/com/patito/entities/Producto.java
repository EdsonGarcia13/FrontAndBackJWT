
package com.patito.entities;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "producto")
public class Producto {
    @Id
    private Long hawa;
    private double precioLista;
    private double descuento;
    private int existencias;

    @ManyToMany(mappedBy = "productos")
    private Set<Pedido> pedidos = new HashSet<>();
}