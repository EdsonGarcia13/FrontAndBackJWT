package com.patito.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "pedido")
public class Pedido {
    @Id
    private Long id;
    private Date fecha;
    private String ipUsuario;
    private String tienda;
    private String cliente;
    private String vendedor;
    private double descuento;
    private String estatus;

    @ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY)
    private Set<Producto> productos = new HashSet<>();
}