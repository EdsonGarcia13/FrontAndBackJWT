package com.patito;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.patito.entities.Rol;
import com.patito.entities.Usuario;
import com.patito.entities.UsuarioRol;
import com.patito.service.UsuarioService;

// import com.patito.service.UsuarioService;

@SpringBootApplication
public class PatitoApplication implements CommandLineRunner{
	@Autowired
	private UsuarioService usuarioService;
	public static void main(String[] args) {
		SpringApplication.run(PatitoApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		/*try{
			Usuario usuario = new Usuario();

			usuario.setNombre("Edson");
			usuario.setApellido("Garcia");
			usuario.setUsername("Contreras");
			usuario.setPassword("12345");
			usuario.setEmail("edson@gmail.com");
			usuario.setTelefono("123123123");
			usuario.setPerfil("ADMIN");

			Rol rol = new Rol();
			rol.setRolId(1L);
			rol.setRolNombre("ADMIN");

			Set<UsuarioRol> usuariosRoles = new HashSet<>();
			UsuarioRol usuarioRol = new UsuarioRol();
			usuarioRol.setRol(rol);
			usuarioRol.setUsuario(usuario);
			usuariosRoles.add(usuarioRol);

			Usuario usuarioGuardado = usuarioService.guardarUsuario(usuario,usuariosRoles);
			System.out.println(usuarioGuardado.getUsername());
		}catch (Exception e){
			System.out.println(e.getMessage());
		}*/
	}

}
