package com.patito.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.patito.entities.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario,Long> {

    public Usuario findByUsername(String username);

}
