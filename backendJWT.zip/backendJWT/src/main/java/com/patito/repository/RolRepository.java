package com.patito.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.patito.entities.Rol;

public interface RolRepository extends JpaRepository<Rol,Long> {
}
