package com.patito.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.patito.entities.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    
}