package com.patito.patito;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatitoApplicationTests {

	@Test
	void contextLoads() {
	}

}
